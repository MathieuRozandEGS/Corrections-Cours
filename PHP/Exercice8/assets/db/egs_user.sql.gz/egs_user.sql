-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : sam. 25 fév. 2023 à 09:15
-- Version du serveur : 10.4.25-MariaDB
-- Version de PHP : 8.1.10

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `egs`
--
DROP DATABASE IF EXISTS `egs`;
CREATE DATABASE IF NOT EXISTS `egs` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `egs`;

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `first_name` varchar(100) DEFAULT NULL,
  `last_name` varchar(100) DEFAULT NULL,
  `birth_date` date DEFAULT NULL,
  `pseudo` varchar(255) NOT NULL,
  `about` varchar(3000) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) CHARACTER SET latin1 NOT NULL,
  `roles` longtext DEFAULT NULL COMMENT '(DC2Type:array)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `first_name`, `last_name`, `birth_date`, `pseudo`, `about`, `email`, `password`, `roles`) VALUES
(1, 'Iyed', 'Ben Abdennebi', NULL, 'KIZI', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'iyed.benabdennebi@egs.school', '', NULL),
(2, 'Adrien', 'Bonnet', NULL, 'Adiclo', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'adrien.bonnet@egs.school', '', NULL),
(3, 'Driss', 'Costa', NULL, 'Tartopaumme', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'driss.costa@egs.school', '', NULL),
(4, 'Kylian', 'Dijoux', NULL, 'NepTroX', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'kylian.dijoux@egs.school', '', NULL),
(5, 'Esteban', 'Duflos', NULL, 'Esteflos', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'esteban.duflos@egs.school', '', NULL),
(6, 'Théo', 'Dumontet', NULL, 'Terapyy', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'theo.dumontet@egs.school', '', NULL),
(7, 'Morgan', 'Dupuy', NULL, 'Tinoug', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'morgan.dupuy@egs.school', '', NULL),
(8, 'Yann', 'Eysseric', NULL, 'Ourtof', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'yann.eysseric@egs.school', '', NULL),
(9, 'Baptiste', 'Juin', NULL, 'Batigoal', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'baptiste.juin@egs.school', '', NULL),
(10, 'Mher', 'Khoylunts', NULL, 'T-34', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'mher.khoylunts@egs.school', '', NULL),
(11, 'Mickael', 'Larivière', NULL, 'Max_of_darkness', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'mickael.lariviere@egs.school', '', NULL),
(12, 'Maxime', 'Le Berre', NULL, 'Happy', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'maxime.leberre@egs.school', '', NULL),
(13, 'Jarod', 'Molinie', NULL, 'Whitemage', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'jarod.molinie@egs.school', '', NULL),
(14, 'Alex', 'Morel', NULL, 'Aloux', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'alex.morel@egs.school', '', NULL),
(15, 'Olivier', 'Naud', NULL, 'Papi', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'olivier.naud@egs.school', '', NULL),
(16, 'Evan', 'Rallu', NULL, 'ExpertLymphe33', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'evan.rallu@egs.school', '', NULL),
(17, 'Charlie', 'Scatoli', NULL, 'Marlow', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'charlie.scatoli@egs.school', '', NULL),
(18, 'Mehdi', 'Van Reckem', NULL, 'Kimahri', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.', 'mehdi.vanreckem@egs.school', '', NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
